from redisvl.version import __version__

all = ["__version__"]
